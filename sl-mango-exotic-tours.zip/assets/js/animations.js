/**
 * SL MANGO EXOTIC TOURS — GSAP ANIMATIONS & SCROLLTRIGGERS
 * 
 * Cinematic hero entrances, scroll-triggered reveals, timeline animations,
 * and responsive motion scaling with strict prefers-reduced-motion checks.
 * Content remains 100% visible and accessible if GSAP is unavailable.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Check for reduced motion preference
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReducedMotion) {
    console.info('Motion animations disabled per user prefers-reduced-motion setting.');
    return;
  }

  // Check if GSAP is loaded
  if (typeof gsap === 'undefined') {
    console.info('GSAP not detected; content remains fully accessible with standard CSS.');
    return;
  }

  // Register ScrollTrigger if available
  if (typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
  }

  initHeroAnimations();
  initScrollReveals();
  initTimelineAnimations();
});

/**
 * Cinematic Hero Entrances
 */
function initHeroAnimations() {
  const hero = document.querySelector('.hero');
  if (!hero) return;

  const bgMedia = hero.querySelectorAll('.hero-bg-media img, .hero-bg-media video');
  const eyebrow = hero.querySelector('.hero-eyebrow');
  const title = hero.querySelector('.hero-title');
  const lead = hero.querySelector('.hero-lead');
  const actions = hero.querySelector('.hero-actions');
  const scrollIndicator = hero.querySelector('.hero-scroll-indicator');

  const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

  // Subtle background zoom settle
  if (bgMedia && bgMedia.length) {
    tl.fromTo(bgMedia, 
      { scale: 1.10, opacity: 0.85 }, 
      { scale: 1.04, opacity: 1, duration: 1.6 }
    );
  }

  // Staggered text reveals
  const elements = [eyebrow, title, lead, actions, scrollIndicator].filter(Boolean);
  if (elements.length) {
    tl.fromTo(elements,
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.85, stagger: 0.15 },
      "-=1.2"
    );
  }
}

/**
 * Scroll-Triggered Section Reveals
 */
function initScrollReveals() {
  if (typeof ScrollTrigger === 'undefined') return;

  // Section Headers
  const sectionHeaders = document.querySelectorAll('.section-header');
  sectionHeaders.forEach(header => {
    const title = header.querySelector('.section-title');
    const tag = header.querySelector('.section-tag');
    const desc = header.querySelector('.section-description');
    const line = header.querySelector('.accent-line');

    const headerTl = gsap.timeline({
      scrollTrigger: {
        trigger: header,
        start: 'top 85%',
        toggleActions: 'play none none none'
      }
    });

    if (tag) headerTl.from(tag, { y: 15, opacity: 0, duration: 0.5 });
    if (title) headerTl.from(title, { y: 20, opacity: 0, duration: 0.6 }, "-=0.3");
    if (line) headerTl.from(line, { scaleX: 0, transformOrigin: 'left center', duration: 0.5 }, "-=0.3");
    if (desc) headerTl.from(desc, { y: 15, opacity: 0, duration: 0.5 }, "-=0.3");
  });

  // Staggered Cards (Destinations, Tours, Vehicles, Steps)
  const cardGrids = [
    '.destinations-grid .destination-card',
    '.tours-grid .tour-card',
    '.vehicles-grid .vehicle-card',
    '.steps-grid .step-card',
    '.services-grid .service-card',
    '.gallery-grid .gallery-card'
  ];

  cardGrids.forEach(selector => {
    const cards = document.querySelectorAll(selector);
    if (!cards.length) return;

    ScrollTrigger.batch(cards, {
      start: 'top 90%',
      onEnter: (batch) => {
        gsap.fromTo(batch,
          { y: 35, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.65, stagger: 0.12, ease: 'power2.out', overwrite: 'auto' }
        );
      },
      once: true
    });
  });

  // Editorial Split Sections
  const editorialSections = document.querySelectorAll('.editorial-grid');
  editorialSections.forEach(section => {
    const media = section.querySelector('.editorial-media-wrapper');
    const content = section.querySelector('.editorial-content');

    if (media) {
      gsap.from(media, {
        scrollTrigger: {
          trigger: section,
          start: 'top 80%'
        },
        x: -30,
        opacity: 0,
        duration: 0.9,
        ease: 'power2.out'
      });
    }

    if (content) {
      gsap.from(content, {
        scrollTrigger: {
          trigger: section,
          start: 'top 80%'
        },
        x: 30,
        opacity: 0,
        duration: 0.9,
        delay: 0.15,
        ease: 'power2.out'
      });
    }
  });
}

/**
 * Itinerary Day-by-Day Timeline Scroll Animation
 */
function initTimelineAnimations() {
  if (typeof ScrollTrigger === 'undefined') return;

  const dayCards = document.querySelectorAll('.itinerary-day-card');
  if (!dayCards.length) return;

  dayCards.forEach((card, index) => {
    const node = card.querySelector('.day-marker-node');
    const content = card.querySelector('.day-content-card');

    const cardTl = gsap.timeline({
      scrollTrigger: {
        trigger: card,
        start: 'top 85%',
        toggleActions: 'play none none none'
      }
    });

    if (node) {
      cardTl.from(node, { scale: 0.6, opacity: 0, duration: 0.45, ease: 'back.out(1.7)' });
    }

    if (content) {
      cardTl.from(content, { y: 25, opacity: 0, duration: 0.6, ease: 'power2.out' }, "-=0.25");
    }
  });
}
