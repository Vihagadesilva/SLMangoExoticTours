/**
 * SL MANGO EXOTIC TOURS — GLOBAL APPLICATION SCRIPT
 * 
 * Handles global navigation, sticky header transitions, mobile menu drawer,
 * shared gallery preview rendering, toast notifications, and common utilities.
 */

document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  initMobileNav();
  initHeroVideo();
  initSharedGalleryPreviews();
  initCurrentYear();
});

/**
 * Sticky Header on Scroll
 */
function initHeader() {
  const header = document.querySelector('.site-header');
  if (!header) return;

  const handleScroll = () => {
    if (window.scrollY > 40) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  };

  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll(); // Trigger initial state
}

/**
 * Mobile Navigation Drawer & Backdrop
 */
function initMobileNav() {
  const toggleBtn = document.querySelector('.mobile-menu-toggle');
  const navMenu = document.querySelector('.nav-menu');
  let backdrop = document.querySelector('.nav-backdrop');

  if (!toggleBtn || !navMenu) return;

  // Create backdrop element if not already in DOM
  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.className = 'nav-backdrop';
    document.body.appendChild(backdrop);
  }

  const openMenu = () => {
    toggleBtn.classList.add('is-active');
    toggleBtn.setAttribute('aria-expanded', 'true');
    navMenu.classList.add('is-open');
    backdrop.classList.add('is-visible');
    document.body.style.overflow = 'hidden';
  };

  const closeMenu = () => {
    toggleBtn.classList.remove('is-active');
    toggleBtn.setAttribute('aria-expanded', 'false');
    navMenu.classList.remove('is-open');
    backdrop.classList.remove('is-visible');
    document.body.style.overflow = '';
  };

  toggleBtn.addEventListener('click', () => {
    const isOpen = navMenu.classList.contains('is-open');
    if (isOpen) {
      closeMenu();
    } else {
      openMenu();
    }
  });

  backdrop.addEventListener('click', closeMenu);

  // Close menu when clicking any nav link
  navMenu.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', closeMenu);
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && navMenu.classList.contains('is-open')) {
      closeMenu();
    }
  });
}

/**
 * Renders the Shared Gallery Preview on any page with `.shared-gallery-preview-mount`
 */
function initSharedGalleryPreviews() {
  const mounts = document.querySelectorAll('.shared-gallery-preview-mount');
  if (!mounts.length || typeof GALLERY_DATA === 'undefined') return;

  // Select 5 curated photos spanning themes
  const previewItems = GALLERY_DATA.slice(0, 5);

  mounts.forEach(mount => {
    const previewGrid = document.createElement('div');
    previewGrid.className = 'shared-gallery-preview';

    previewItems.forEach(item => {
      const thumb = document.createElement('div');
      thumb.className = 'preview-thumb';
      thumb.setAttribute('data-image', item.image);
      thumb.setAttribute('data-title', item.title);
      thumb.setAttribute('data-caption', item.caption);

      thumb.innerHTML = `
        <img src="${item.thumb}" alt="${item.alt}" loading="lazy" width="300" height="225">
        <div class="preview-thumb-caption">
          <strong>${item.title}</strong>
        </div>
      `;

      // Open in lightbox if available, or link to gallery.html
      thumb.addEventListener('click', () => {
        if (typeof openLightbox === 'function') {
          openLightbox(item.image, item.title, item.caption);
        } else {
          window.location.href = 'gallery.html';
        }
      });

      previewGrid.appendChild(thumb);
    });

    mount.innerHTML = '';
    mount.appendChild(previewGrid);
  });
}

/**
 * Updates dynamic year in footer
 */
function initCurrentYear() {
  const yearEl = document.getElementById('current-year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}

/**
 * Global Toast Notification
 */
function showToast(message, duration = 4500) {
  let toast = document.querySelector('.toast-notification');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.innerHTML = `
      <div class="toast-icon">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"></circle>
          <path d="M12 16v-4M12 8h.01"></path>
        </svg>
      </div>
      <div class="toast-message"></div>
    `;
    document.body.appendChild(toast);
  }

  const messageBox = toast.querySelector('.toast-message');
  if (messageBox) messageBox.textContent = message;

  toast.classList.add('is-visible');

  clearTimeout(window.__toastTimeout);
  window.__toastTimeout = setTimeout(() => {
    toast.classList.remove('is-visible');
  }, duration);
}

/**
 * Hero Background Video Controller (WCAG 2.2.2 Accessible)
 */
function initHeroVideo() {
  const video = document.querySelector('.hero-bg-video');
  const toggleBtn = document.getElementById('heroVideoToggle');
  if (!video || !toggleBtn) return;

  const iconPause = toggleBtn.querySelector('.icon-pause');
  const iconPlay = toggleBtn.querySelector('.icon-play');

  function updateUI(isPlaying) {
    if (isPlaying) {
      if (iconPause) iconPause.style.display = 'block';
      if (iconPlay) iconPlay.style.display = 'none';
      toggleBtn.setAttribute('aria-label', 'Pause background video');
      toggleBtn.setAttribute('title', 'Pause background video');
    } else {
      if (iconPause) iconPause.style.display = 'none';
      if (iconPlay) iconPlay.style.display = 'block';
      toggleBtn.setAttribute('aria-label', 'Play background video');
      toggleBtn.setAttribute('title', 'Play background video');
    }
  }

  // Explicitly set muted properties to satisfy modern browser autoplay policies
  video.muted = true;
  video.defaultMuted = true;

  video.addEventListener('playing', () => {
    updateUI(true);
    const poster = document.querySelector('.hero-bg-poster');
    if (poster) {
      poster.style.opacity = '0';
      poster.style.pointerEvents = 'none';
    }
  });

  // Attempt autoplay immediately
  const playPromise = video.play();
  if (playPromise !== undefined) {
    playPromise.then(() => {
      updateUI(true);
    }).catch(() => {
      updateUI(false);
    });
  }

  toggleBtn.addEventListener('click', () => {
    if (video.paused) {
      video.play().then(() => updateUI(true)).catch(() => {});
    } else {
      video.pause();
      updateUI(false);
    }
  });

  // Handle visibility state changes (pause when tab hidden to save resources)
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (!video.paused) {
        video.pause();
        video.dataset.pausedByVisibility = 'true';
      }
    } else {
      if (video.dataset.pausedByVisibility === 'true') {
        delete video.dataset.pausedByVisibility;
        if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
          video.play().then(() => updateUI(true)).catch(() => {});
        }
      }
    }
  });
}
